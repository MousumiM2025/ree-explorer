# Rare Earth Elements Explorer (Prototype)

This is a lightweight, GitHub-ready prototype of a Rare Earth Elements Explorer web app using Streamlit.
It includes interactive tables, a mineral occurrences map, a market dashboard, and a simple TF-IDF-based Q&A assistant.

## Files
- `data/` - sample CSVs and small text documents used for Q&A
- `st_app.py` - Streamlit app (run with `streamlit run st_app.py`)
- `requirements.txt` - Python dependencies

## How to use (GitHub Codespaces or locally)

1. **Using GitHub Codespaces** (recommended):
   - Push this repository to GitHub.
   - Open the repo in a Codespace and run:
     ```bash
     pip install -r requirements.txt
     streamlit run st_app.py
     ```
   - Codespaces provides a forwarded port where you can view the Streamlit app.

2. **Locally**:
   - Clone the repository:
     ```bash
     git clone <your-repo-url>
     cd <repo-folder>
     pip install -r requirements.txt
     streamlit run st_app.py
     ```

## Notes
- The Q&A assistant uses a local TF-IDF retrieval over a small corpus (no external API keys required).
- This is a prototype: replace the sample CSVs with real datasets to expand the app.
